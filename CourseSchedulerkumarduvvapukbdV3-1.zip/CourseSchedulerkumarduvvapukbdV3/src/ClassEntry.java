public class ClassEntry {
    private String courseCode;
    private String description;
    private int seats;

    public ClassEntry(String courseCode, String description, int seats) {
        this.courseCode = courseCode;
        this.description = description;
        this.seats = seats;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getDescription() {
        return description;
    }
    
    public int getSeats() {
        return seats;
    }
    
    @Override
    public String toString() {
        return courseCode + " - " + description + " (Seats: " + seats + ")";
    }
}
