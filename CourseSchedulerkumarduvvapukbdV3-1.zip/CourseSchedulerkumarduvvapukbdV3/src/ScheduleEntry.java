public class ScheduleEntry {
    private String courseCode;
    private String description;
    private String status;

    public ScheduleEntry(String courseCode, String description, String status) {
        this.courseCode = courseCode;
        this.description = description;
        this.status = status;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getDescription() {
        return description;
    }
    
    public String getStatus() {
        return status;
    }
    
    @Override
    public String toString() {
        String statusText = status.equals("S") ? "Scheduled" : "Waitlisted";
        return courseCode + " - " + description + " (" + statusText + ")";
    }
}
